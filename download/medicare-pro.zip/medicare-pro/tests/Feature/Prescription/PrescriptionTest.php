<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\MedicalRecord;
use App\Models\Medication;
use App\Models\Patient;
use App\Models\Prescription;
use App\Models\PrescriptionItem;
use App\Models\User;

beforeEach(function () {
    $this->hospital = Hospital::factory()->create();
    $this->department = Department::factory()->create(['hospital_id' => $this->hospital->id]);

    // Create doctor
    $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
    $this->doctor = Doctor::factory()->create([
        'user_id' => $doctorUser->id,
        'department_id' => $this->department->id,
    ]);
    $this->doctorToken = $doctorUser->createToken('auth_token')->plainTextToken;

    // Create patient
    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
    $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);
    $this->patientToken = $patientUser->createToken('auth_token')->plainTextToken;

    // Create pharmacist
    $pharmacistUser = User::factory()->create(['role' => 'pharmacist', 'hospital_id' => $this->hospital->id]);
    $this->pharmacistToken = $pharmacistUser->createToken('auth_token')->plainTextToken;
});

describe('Prescription Management', function () {

    describe('Doctor creating prescriptions', function () {

        test('doctor can create a prescription with items', function () {
            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => $medicalRecord->id,
                    'diagnosis' => 'Bacterial throat infection',
                    'instructions' => 'Take with food, complete full course',
                    'items' => [
                        [
                            'medication_name' => 'Amoxicillin 500mg',
                            'dosage' => '500mg three times daily',
                            'duration' => '7 days',
                            'instructions' => 'Take after meals',
                        ],
                        [
                            'medication_name' => 'Paracetamol 500mg',
                            'dosage' => '500mg every 6 hours as needed',
                            'duration' => '5 days',
                        ],
                    ],
                ]);

            $response->assertCreated()
                ->assertJsonStructure([
                    'message',
                    'data' => ['id', 'doctor_id', 'patient_id', 'diagnosis', 'status', 'items'],
                ]);

            expect($response->json('data.status'))->toBe('pending')
                ->and($response->json('data.items'))->toHaveCount(2);

            $this->assertDatabaseHas('prescriptions', [
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'pending',
            ]);

            $this->assertDatabaseHas('prescription_items', [
                'medication_name' => 'Amoxicillin 500mg',
                'dosage' => '500mg three times daily',
            ]);

            $this->assertDatabaseHas('prescription_items', [
                'medication_name' => 'Paracetamol 500mg',
                'dosage' => '500mg every 6 hours as needed',
            ]);
        });

        test('doctor can list their prescriptions', function () {
            $record1 = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $record2 = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            Prescription::factory()->create([
                'medical_record_id' => $record1->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            Prescription::factory()->create([
                'medical_record_id' => $record2->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->getJson('/api/v1/doctor/prescriptions');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);

            expect($response->json('meta.total'))->toBe(2);
        });

        test('prescription requires at least one item', function () {
            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => $medicalRecord->id,
                    'diagnosis' => 'Some diagnosis',
                    'items' => [],
                ]);

            $response->assertUnprocessable();
        });

        test('prescription item requires medication name, dosage, and duration', function () {
            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => $medicalRecord->id,
                    'diagnosis' => 'Some diagnosis',
                    'items' => [
                        ['dosage' => '500mg'], // missing medication_name and duration
                    ],
                ]);

            $response->assertUnprocessable()
                ->assertJsonValidationErrors([
                    'items.0.medication_name',
                    'items.0.duration',
                ]);
        });

        test('doctor cannot create prescription for another doctors medical record', function () {
            $otherDept = Department::factory()->create(['hospital_id' => $this->hospital->id]);
            $otherDoctor = Doctor::factory()->create(['department_id' => $otherDept->id]);

            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $otherDoctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => $medicalRecord->id,
                    'diagnosis' => 'Unauthorized prescription',
                    'items' => [
                        [
                            'medication_name' => 'Ibuprofen',
                            'dosage' => '400mg',
                            'duration' => '5 days',
                        ],
                    ],
                ]);

            $response->assertForbidden();
        });

        test('non-existent medical record returns validation error', function () {
            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => 99999,
                    'diagnosis' => 'Test',
                    'items' => [
                        [
                            'medication_name' => 'Drug A',
                            'dosage' => '100mg',
                            'duration' => '3 days',
                        ],
                    ],
                ]);

            $response->assertUnprocessable();
        });
    });

    describe('Patient viewing prescriptions', function () {

        test('patient can list their prescriptions', function () {
            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->getJson('/api/v1/patient/prescriptions');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);
        });

        test('patient can view a single prescription', function () {
            $medicalRecord = MedicalRecord::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            PrescriptionItem::factory()->create([
                'prescription_id' => $prescription->id,
                'medication_name' => 'Aspirin',
                'dosage' => '100mg daily',
                'duration' => '30 days',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->getJson("/api/v1/patient/prescriptions/{$prescription->id}");

            $response->assertOk()
                ->assertJsonStructure([
                    'data' => ['id', 'doctor_id', 'patient_id', 'diagnosis', 'status', 'items'],
                ]);
        });
    });

    describe('Pharmacist dispensing', function () {

        test('pharmacist can list pending prescriptions', function () {
            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $medicalRecord = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'pending',
            ]);

            PrescriptionItem::factory()->create([
                'prescription_id' => $prescription->id,
                'medication_name' => 'Amoxicillin',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->pharmacistToken}")
                ->getJson('/api/v1/pharmacist/prescriptions');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);

            expect($response->json('meta.total'))->toBeGreaterThanOrEqual(1);
        });

        test('pharmacist can view a single prescription', function () {
            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $medicalRecord = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->pharmacistToken}")
                ->getJson("/api/v1/pharmacist/prescriptions/{$prescription->id}");

            $response->assertOk()
                ->assertJsonStructure(['data' => ['id', 'diagnosis', 'status', 'items']]);
        });

        test('pharmacist can dispense a pending prescription', function () {
            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $medicalRecord = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->pharmacistToken}")
                ->putJson("/api/v1/pharmacist/prescriptions/{$prescription->id}/dispense");

            $response->assertOk();
            expect($prescription->fresh()->status)->toBe('dispensed');
        });

        test('pharmacist cannot dispense already dispensed prescription', function () {
            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $medicalRecord = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'dispensed',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->pharmacistToken}")
                ->putJson("/api/v1/pharmacist/prescriptions/{$prescription->id}/dispense");

            $response->assertUnprocessable();
        });

        test('dispensing decrements medication stock', function () {
            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $medicalRecord = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $prescription = Prescription::factory()->create([
                'medical_record_id' => $medicalRecord->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'status' => 'pending',
            ]);

            PrescriptionItem::factory()->create([
                'prescription_id' => $prescription->id,
                'medication_name' => 'Paracetamol 500mg',
            ]);

            Medication::factory()->create([
                'hospital_id' => $this->hospital->id,
                'name' => 'Paracetamol 500mg',
                'stock_quantity' => 50,
                'status' => 'available',
            ]);

            $this->withHeader('Authorization', "Bearer {$this->pharmacistToken}")
                ->putJson("/api/v1/pharmacist/prescriptions/{$prescription->id}/dispense");

            $medication = Medication::where('name', 'Paracetamol 500mg')->first();
            expect($medication->stock_quantity)->toBe(49);
        });
    });

    describe('Role access control', function () {

        test('patient cannot create prescriptions', function () {
            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->postJson('/api/v1/doctor/prescriptions', [
                    'medical_record_id' => 1,
                    'diagnosis' => 'Self-prescribed',
                    'items' => [
                        ['medication_name' => 'Vitamins', 'dosage' => '1 daily', 'duration' => '30 days'],
                    ],
                ]);

            $response->assertForbidden();
        });

        test('doctor cannot dispense prescriptions', function () {
            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->getJson('/api/v1/pharmacist/prescriptions');

            $response->assertForbidden();
        });
    });
});
