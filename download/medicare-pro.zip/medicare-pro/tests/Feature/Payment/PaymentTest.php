<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\Invoice;
use App\Models\Patient;
use App\Models\User;

beforeEach(function () {
    $this->hospital = Hospital::factory()->create();
    $this->department = Department::factory()->create(['hospital_id' => $this->hospital->id]);
    $this->doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
    $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);
    $this->patientUser = $patientUser;
    $this->token = $patientUser->createToken('auth_token')->plainTextToken;
});

describe('Payment Management', function () {

    describe('Invoice listing', function () {

        test('patient can list their invoices', function () {
            Invoice::factory()->count(3)->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->getJson('/api/v1/patient/invoices');

            $response->assertOk()
                ->assertJsonStructure([
                    'data',
                    'meta' => ['current_page', 'last_page', 'per_page', 'total'],
                ]);

            expect($response->json('meta.total'))->toBe(3);
        });

        test('patient only sees their own invoices', function () {
            $otherPatient = Patient::factory()->create();

            Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            Invoice::factory()->create([
                'patient_id' => $otherPatient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->getJson('/api/v1/patient/invoices');

            expect($response->json('meta.total'))->toBe(1);
        });

        test('invoices are paginated', function () {
            Invoice::factory()->count(20)->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->getJson('/api/v1/patient/invoices?per_page=5');

            expect($response->json('data'))->toHaveCount(5)
                ->and($response->json('meta.last_page'))->toBe(4);
        });
    });

    describe('Payment creation', function () {

        test('patient can pay a pending invoice with cash', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 100.00,
                'tax' => 15.00,
                'total_amount' => 115.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 115.00,
                    'payment_method' => 'cash',
                ]);

            $response->assertOk();
            expect($invoice->fresh()->status)->toBe('paid');

            $this->assertDatabaseHas('payments', [
                'invoice_id' => $invoice->id,
                'amount' => '115.00',
                'payment_method' => 'cash',
                'status' => 'success',
            ]);
        });

        test('patient can pay invoice with card and transaction id', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 200.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 200.00,
                    'payment_method' => 'card',
                    'transaction_id' => 'txn_card_abc123',
                ]);

            $response->assertOk();

            $this->assertDatabaseHas('payments', [
                'invoice_id' => $invoice->id,
                'payment_method' => 'card',
                'transaction_id' => 'txn_card_abc123',
            ]);
        });

        test('patient can pay invoice with online method', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 75.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 75.00,
                    'payment_method' => 'online',
                ]);

            $response->assertOk();
            expect($invoice->fresh()->status)->toBe('paid');
        });

        test('partial payment updates invoice to partially_paid', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 300.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 100.00,
                    'payment_method' => 'cash',
                ]);

            $response->assertOk();
            expect($invoice->fresh()->status)->toBe('partially_paid');
        });

        test('cannot pay already paid invoice', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'paid',
                'paid_at' => now(),
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 100.00,
                    'payment_method' => 'cash',
                ]);

            $response->assertUnprocessable();
        });

        test('cannot pay more than remaining amount', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 200.00,
                    'payment_method' => 'cash',
                ]);

            $response->assertUnprocessable();
        });

        test('cannot pay another patients invoice', function () {
            $otherPatient = Patient::factory()->create();
            $invoice = Invoice::factory()->create([
                'patient_id' => $otherPatient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 100.00,
                    'payment_method' => 'cash',
                ]);

            $response->assertForbidden();
        });

        test('payment requires valid payment method', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 100.00,
                    'payment_method' => 'bitcoin',
                ]);

            $response->assertUnprocessable()
                ->assertJsonValidationErrors(['payment_method']);
        });

        test('payment requires positive amount', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'pending',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->token}")
                ->postJson("/api/v1/patient/invoices/{$invoice->id}/pay", [
                    'amount' => 0,
                    'payment_method' => 'cash',
                ]);

            $response->assertUnprocessable();
        });

        test('unauthenticated user cannot access invoice endpoints', function () {
            $response = $this->getJson('/api/v1/patient/invoices');
            $response->assertUnauthorized();
        });
    });
});
