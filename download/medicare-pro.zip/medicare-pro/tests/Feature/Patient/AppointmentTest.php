<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\Patient;
use App\Models\User;

test('patient can book appointment', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['department_id' => $department->id]);

    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $hospital->id]);
    $patient = Patient::factory()->create(['user_id' => $patientUser->id]);

    $token = $patientUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->postJson('/api/v1/patient/appointments', [
            'doctor_id' => $doctor->id,
            'hospital_id' => $hospital->id,
            'department_id' => $department->id,
            'appointment_date' => now()->addDays(3)->toDateString(),
            'appointment_time' => '10:30',
            'symptoms' => 'Headache and fever',
        ]);

    $response->assertCreated()
        ->assertJsonStructure([
            'message',
            'data' => ['id', 'patient_id', 'doctor_id', 'status', 'queue_display_number'],
        ]);
});

test('patient can list appointments', function () {
    $user = User::factory()->create(['role' => 'patient']);
    $patient = Patient::factory()->create(['user_id' => $user->id]);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/patient/appointments');

    $response->assertOk()
        ->assertJsonStructure(['data', 'meta']);
});

test('patient can cancel appointment', function () {
    $user = User::factory()->create(['role' => 'patient']);
    $patient = Patient::factory()->create(['user_id' => $user->id]);
    $appointment = Appointment::factory()->create([
        'patient_id' => $patient->id,
        'status' => 'pending',
    ]);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->deleteJson("/api/v1/patient/appointments/{$appointment->id}");

    $response->assertOk();
    expect($appointment->fresh()->status)->toBe('cancelled');
});
