<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\Patient;
use App\Models\User;

test('receptionist can check in patient', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['department_id' => $department->id]);
    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $hospital->id]);
    $patient = Patient::factory()->create(['user_id' => $patientUser->id]);

    $appointment = Appointment::factory()->create([
        'patient_id' => $patient->id,
        'doctor_id' => $doctor->id,
        'hospital_id' => $hospital->id,
        'department_id' => $department->id,
        'status' => 'confirmed',
    ]);

    $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $hospital->id]);
    $token = $receptionistUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->putJson("/api/v1/receptionist/appointments/{$appointment->id}/check-in");

    $response->assertOk();
    expect($appointment->fresh()->status)->toBe('checked_in');
    expect($appointment->fresh()->queue_number)->not->toBeNull();
});

test('receptionist can register walk-in patient', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['department_id' => $department->id]);
    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $hospital->id]);
    $patient = Patient::factory()->create(['user_id' => $patientUser->id]);

    $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $hospital->id]);
    $token = $receptionistUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->postJson('/api/v1/receptionist/walk-in', [
            'patient_id' => $patient->id,
            'doctor_id' => $doctor->id,
            'department_id' => $department->id,
            'symptoms' => 'Acute pain',
        ]);

    $response->assertCreated();
    expect($response->json('data.type'))->toBe('walk_in');
});
