<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\User;

beforeEach(function () {
    $this->hospital = Hospital::factory()->create();
    $this->department = Department::factory()->create(['hospital_id' => $this->hospital->id]);

    $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
    $this->doctor = Doctor::factory()->create([
        'user_id' => $doctorUser->id,
        'department_id' => $this->department->id,
    ]);
    $this->doctorUser = $doctorUser;
    $this->doctorToken = $doctorUser->createToken('auth_token')->plainTextToken;

    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
    $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);
    $this->patientUser = $patientUser;
    $this->patientToken = $patientUser->createToken('auth_token')->plainTextToken;
});

describe('Medical Record Management', function () {

    describe('Doctor creating medical records', function () {

        test('doctor can create a medical record with all fields', function () {
            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
                'status' => 'in_progress',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                    'vital_signs' => [
                        'blood_pressure' => '120/80',
                        'temperature' => 37.2,
                        'weight' => 72.5,
                        'height' => 175,
                        'heart_rate' => 78,
                    ],
                    'symptoms' => 'Fever, sore throat, body aches',
                    'diagnosis' => 'Upper respiratory tract infection',
                    'notes' => 'Prescribe antibiotics if bacterial origin confirmed',
                ]);

            $response->assertCreated()
                ->assertJsonStructure([
                    'message',
                    'data' => ['id', 'patient_id', 'doctor_id', 'vital_signs', 'symptoms', 'diagnosis'],
                ]);

            $this->assertDatabaseHas('medical_records', [
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $record = MedicalRecord::where('appointment_id', $appointment->id)->first();
            expect($record->vital_signs)->toBeArray()
                ->and($record->vital_signs['blood_pressure'])->toBe('120/80')
                ->and($record->vital_signs['temperature'])->toBe(37.2)
                ->and($record->diagnosis)->toBe('Upper respiratory tract infection');
        });

        test('doctor can create medical record with minimal data', function () {
            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                ]);

            $response->assertCreated();
            $this->assertDatabaseHas('medical_records', [
                'appointment_id' => $appointment->id,
            ]);
        });

        test('doctor can update an existing medical record', function () {
            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $record = MedicalRecord::factory()->create([
                'appointment_id' => $appointment->id,
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
                'diagnosis' => 'Initial diagnosis',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->putJson("/api/v1/doctor/medical-records/{$record->id}", [
                    'diagnosis' => 'Updated diagnosis: Pneumonia',
                    'notes' => 'Chest X-ray confirms right lower lobe consolidation',
                ]);

            $response->assertOk()
                ->assertJsonPath('data.diagnosis', 'Updated diagnosis: Pneumonia');

            expect($record->fresh()->diagnosis)->toBe('Updated diagnosis: Pneumonia');
        });

        test('doctor cannot create medical record for another doctors appointment', function () {
            $otherDept = Department::factory()->create(['hospital_id' => $this->hospital->id]);
            $otherDoctor = Doctor::factory()->create(['department_id' => $otherDept->id]);

            $appointment = Appointment::factory()->create([
                'doctor_id' => $otherDoctor->id,
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                    'diagnosis' => 'Attempted unauthorized diagnosis',
                ]);

            $response->assertForbidden();
        });

        test('doctor cannot update another doctors medical record', function () {
            $otherDept = Department::factory()->create(['hospital_id' => $this->hospital->id]);
            $otherDoctor = Doctor::factory()->create(['department_id' => $otherDept->id]);

            $record = MedicalRecord::factory()->create([
                'doctor_id' => $otherDoctor->id,
                'patient_id' => $this->patient->id,
                'diagnosis' => 'Original diagnosis',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->putJson("/api/v1/doctor/medical-records/{$record->id}", [
                    'diagnosis' => 'Unauthorized update',
                ]);

            $response->assertForbidden();
        });

        test('creating medical record for same appointment updates existing one', function () {
            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                    'diagnosis' => 'First version',
                ]);

            $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                    'diagnosis' => 'Updated version',
                    'symptoms' => 'Added symptoms',
                ]);

            // Only one medical record per appointment
            expect(MedicalRecord::where('appointment_id', $appointment->id)->count())->toBe(1);
            expect(MedicalRecord::where('appointment_id', $appointment->id)->first()->diagnosis)
                ->toBe('Updated version');
        });

        test('non-existent appointment returns validation error', function () {
            $response = $this->withHeader('Authorization', "Bearer {$this->doctorToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => 99999,
                ]);

            $response->assertUnprocessable();
        });
    });

    describe('Patient accessing medical records', function () {

        test('patient can list their medical records', function () {
            MedicalRecord::factory()->count(3)->create([
                'patient_id' => $this->patient->id,
                'doctor_id' => $this->doctor->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->getJson('/api/v1/patient/medical-records');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);
        });

        test('patient can view a single medical record', function () {
            $record = MedicalRecord::factory()->create([
                'patient_id' => $this->patient->id,
                'doctor_id' => $this->doctor->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->getJson("/api/v1/patient/medical-records/{$record->id}");

            $response->assertOk()
                ->assertJsonStructure([
                    'data' => ['id', 'patient_id', 'doctor_id', 'diagnosis', 'vital_signs'],
                ]);
        });

        test('unauthenticated user cannot access medical records', function () {
            $response = $this->getJson('/api/v1/patient/medical-records');
            $response->assertUnauthorized();
        });
    });

    describe('Role access control', function () {

        test('patient cannot create medical records', function () {
            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'patient_id' => $this->patient->id,
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$this->patientToken}")
                ->postJson('/api/v1/doctor/medical-records', [
                    'appointment_id' => $appointment->id,
                    'diagnosis' => 'Self diagnosis attempt',
                ]);

            $response->assertForbidden();
        });
    });
});
