<?php

use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\User;

test('patient cannot access doctor endpoints', function () {
    $user = User::factory()->create(['role' => 'patient']);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/doctor/dashboard');

    $response->assertForbidden();
});

test('doctor cannot access admin endpoints', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $user = User::factory()->create(['role' => 'doctor', 'hospital_id' => $hospital->id]);
    Doctor::factory()->create(['user_id' => $user->id, 'department_id' => $department->id]);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/admin/dashboard');

    $response->assertForbidden();
});

test('super admin can access all hospitals', function () {
    $user = User::factory()->create(['role' => 'super_admin']);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/super-admin/hospitals');

    $response->assertOk()
        ->assertJsonStructure(['data', 'meta']);
});

test('unauthenticated user cannot access protected endpoints', function () {
    $response = $this->getJson('/api/v1/patient/appointments');
    $response->assertUnauthorized();
});

test('hospital admin cannot access other hospital data', function () {
    $hospital1 = Hospital::factory()->create();
    $hospital2 = Hospital::factory()->create();
    $adminUser = User::factory()->create(['role' => 'hospital_admin', 'hospital_id' => $hospital1->id]);
    $token = $adminUser->createToken('auth_token')->plainTextToken;

    // Try to access hospital 2's settings
    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/admin/settings');

    // Should only see their own hospital's settings
    $response->assertOk();
});
