<?php

use App\Models\Hospital;
use App\Models\Notification;
use App\Models\Patient;
use App\Models\User;

describe('Notification Management', function () {

    beforeEach(function () {
        $this->hospital = Hospital::factory()->create();
        $this->user = User::factory()->create([
            'role' => 'patient',
            'hospital_id' => $this->hospital->id,
        ]);
        Patient::factory()->create(['user_id' => $this->user->id]);
        $this->token = $this->user->createToken('auth_token')->plainTextToken;
    });

    test('user can list their notifications', function () {
        Notification::factory()->count(5)->create([
            'user_id' => $this->user->id,
            'is_read' => false,
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications');

        $response->assertOk()
            ->assertJsonStructure([
                'data',
                'meta' => [
                    'current_page',
                    'last_page',
                    'per_page',
                    'total',
                    'unread_count',
                ],
            ]);

        expect($response->json('meta.total'))->toBe(5);
    });

    test('unread count is accurate in notification listing', function () {
        Notification::factory()->count(3)->create([
            'user_id' => $this->user->id,
            'is_read' => false,
        ]);

        Notification::factory()->count(2)->create([
            'user_id' => $this->user->id,
            'is_read' => true,
            'read_at' => now(),
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications');

        expect($response->json('meta.total'))->toBe(5)
            ->and($response->json('meta.unread_count'))->toBe(3);
    });

    test('notifications are paginated', function () {
        Notification::factory()->count(25)->create([
            'user_id' => $this->user->id,
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications?per_page=10');

        $response->assertOk();
        expect($response->json('meta.per_page'))->toBe(10)
            ->and($response->json('data'))->toHaveCount(10)
            ->and($response->json('meta.last_page'))->toBe(3);
    });

    test('user can mark a notification as read', function () {
        $notification = Notification::factory()->create([
            'user_id' => $this->user->id,
            'is_read' => false,
            'read_at' => null,
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->putJson("/api/v1/patient/notifications/{$notification->id}/read");

        $response->assertOk()
            ->assertJsonStructure(['message', 'data']);

        expect($notification->fresh()->is_read)->toBeTrue()
            ->and($notification->fresh()->read_at)->not->toBeNull();
    });

    test('user cannot mark another users notification as read', function () {
        $otherUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
        $otherNotification = Notification::factory()->create([
            'user_id' => $otherUser->id,
            'is_read' => false,
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->putJson("/api/v1/patient/notifications/{$otherNotification->id}/read");

        $response->assertForbidden();
    });

    test('notification list is ordered by latest first', function () {
        $oldNotification = Notification::factory()->create([
            'user_id' => $this->user->id,
            'created_at' => now()->subDays(2),
        ]);

        $newNotification = Notification::factory()->create([
            'user_id' => $this->user->id,
            'created_at' => now(),
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications');

        $ids = collect($response->json('data'))->pluck('id');
        expect($ids->first())->toBe($newNotification->id)
            ->and($ids->last())->toBe($oldNotification->id);
    });

    test('user only sees their own notifications', function () {
        $otherUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);

        Notification::factory()->count(3)->create([
            'user_id' => $this->user->id,
        ]);

        Notification::factory()->count(2)->create([
            'user_id' => $otherUser->id,
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications');

        expect($response->json('meta.total'))->toBe(3);
    });

    test('unauthenticated user cannot access notifications', function () {
        $response = $this->getJson('/api/v1/patient/notifications');
        $response->assertUnauthorized();
    });

    test('notification can store data as json', function () {
        $notification = Notification::factory()->create([
            'user_id' => $this->user->id,
            'data' => ['appointment_id' => 42, 'type' => 'reminder'],
        ]);

        $response = $this->withHeader('Authorization', "Bearer {$this->token}")
            ->getJson('/api/v1/patient/notifications');

        $dataNotification = collect($response->json('data'))->first(
            fn ($n) => $n['id'] === $notification->id
        );

        expect($dataNotification)->not->toBeNull();
    });
});
