<?php

use App\Models\Hospital;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

describe('Patient Registration', function () {

    test('patient can register with valid data', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Ahmed Al-Rashid',
            'email' => 'ahmed@example.com',
            'phone' => '+966501234567',
            'password' => 'SecurePass123',
            'password_confirmation' => 'SecurePass123',
            'gender' => 'male',
            'date_of_birth' => '1990-05-15',
            'blood_type' => 'O+',
        ]);

        $response->assertCreated()
            ->assertJsonStructure([
                'message',
                'data' => [
                    'user' => ['id', 'name', 'email', 'role'],
                    'token',
                    'token_type',
                ],
            ]);

        expect($response->json('data.user.role'))->toBe('patient');
        expect($response->json('data.token_type'))->toBe('Bearer');

        $this->assertDatabaseHas('users', [
            'email' => 'ahmed@example.com',
            'role' => 'patient',
            'status' => 'active',
        ]);

        $this->assertDatabaseHas('patients', [
            'gender' => 'male',
            'blood_type' => 'O+',
        ]);
    });

    test('patient can register with hospital association', function () {
        $hospital = Hospital::factory()->create(['default_language' => 'en']);

        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Sara Mohammed',
            'email' => 'sara@example.com',
            'phone' => '+966509876543',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
            'hospital_id' => $hospital->id,
        ]);

        $response->assertCreated();

        $user = User::where('email', 'sara@example.com')->first();
        expect($user->hospital_id)->toBe($hospital->id)
            ->and($user->language_preference)->toBe('en');
    });

    test('registration fails with duplicate email', function () {
        User::factory()->create(['email' => 'duplicate@example.com']);

        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'duplicate@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['email']);
    });

    test('registration fails with duplicate phone', function () {
        User::factory()->create(['phone' => '+966509998887']);

        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'new@example.com',
            'phone' => '+966509998887',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['phone']);
    });

    test('registration fails with missing required fields', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Incomplete User',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['email', 'phone', 'password']);
    });

    test('registration fails with password mismatch', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'DifferentPass456',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['password']);
    });

    test('registration fails with short password', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '+966501112233',
            'password' => 'short',
            'password_confirmation' => 'short',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['password']);
    });

    test('registration fails with invalid email format', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'not-an-email',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['email']);
    });

    test('registration fails with invalid blood type', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
            'blood_type' => 'XX',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['blood_type']);
    });

    test('registration fails with invalid gender', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
            'gender' => 'unknown',
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['gender']);
    });

    test('registration fails with non-existent hospital', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
            'hospital_id' => 99999,
        ]);

        $response->assertUnprocessable()
            ->assertJsonValidationErrors(['hospital_id']);
    });

    test('registered user can authenticate with returned token', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Token Test',
            'email' => 'tokentest@example.com',
            'phone' => '+966504445566',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $token = $response->json('data.token');

        $meResponse = $this->withHeader('Authorization', "Bearer {$token}")
            ->getJson('/api/v1/auth/me');

        $meResponse->assertOk()
            ->assertJsonPath('data.email', 'tokentest@example.com');
    });

    test('password is hashed on registration', function () {
        $this->postJson('/api/v1/auth/register', [
            'name' => 'Hashed Pass User',
            'email' => 'hashed@example.com',
            'phone' => '+966507778889',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $user = User::where('email', 'hashed@example.com')->first();
        expect(Hash::check('Password123', $user->password))->toBeTrue();
    });

    test('user defaults to arabic language when no hospital', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Arabic Default',
            'email' => 'arabic@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $user = User::where('email', 'arabic@example.com')->first();
        expect($user->language_preference)->toBe('ar');
    });

    test('registration creates patient record automatically', function () {
        $response = $this->postJson('/api/v1/auth/register', [
            'name' => 'Auto Patient',
            'email' => 'autopatient@example.com',
            'phone' => '+966501112233',
            'password' => 'Password123',
            'password_confirmation' => 'Password123',
        ]);

        $user = User::where('email', 'autopatient@example.com')->first();
        expect($user->patient)->not->toBeNull();
        expect($user->patient)->toBeInstanceOf(Patient::class);
    });
});
