<?php

use App\Models\User;
use Illuminate\Support\Facades\Hash;

test('patient can register', function () {
    $response = $this->postJson('/api/v1/auth/register', [
        'name' => 'Test Patient',
        'email' => 'test@example.com',
        'phone' => '+966509999999',
        'password' => 'password123',
        'password_confirmation' => 'password123',
    ]);

    $response->assertCreated()
        ->assertJsonStructure([
            'message',
            'data' => ['user', 'token', 'token_type'],
        ]);

    $this->assertDatabaseHas('users', ['email' => 'test@example.com', 'role' => 'patient']);
    $this->assertDatabaseHas('patients', []);
});

test('user can login with valid credentials', function () {
    $user = User::factory()->create([
        'password' => Hash::make('password123'),
        'role' => 'patient',
        'status' => 'active',
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'email' => $user->email,
        'password' => 'password123',
    ]);

    $response->assertOk()
        ->assertJsonStructure(['message', 'data' => ['user', 'token', 'token_type']]);
});

test('login fails with invalid credentials', function () {
    $response = $this->postJson('/api/v1/auth/login', [
        'email' => 'nonexistent@example.com',
        'password' => 'wrongpassword',
    ]);

    $response->assertUnprocessable();
});

test('authenticated user can logout', function () {
    $user = User::factory()->create(['role' => 'patient']);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->postJson('/api/v1/auth/logout');

    $response->assertOk()
        ->assertJson(['message' => __('auth.logout_success')]);
});

test('authenticated user can get profile', function () {
    $user = User::factory()->create(['role' => 'patient']);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/auth/me');

    $response->assertOk()
        ->assertJsonStructure(['data' => ['id', 'name', 'email', 'role']]);
});

test('user can change language', function () {
    $user = User::factory()->create(['role' => 'patient', 'language_preference' => 'ar']);
    $token = $user->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->postJson('/api/v1/auth/change-language', ['language' => 'en']);

    $response->assertOk();
    $this->assertDatabaseHas('users', ['id' => $user->id, 'language_preference' => 'en']);
});
