<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\User;

test('doctor can view dashboard', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['user_id' => $doctorUser->id, 'department_id' => $department->id]);

    $token = $doctorUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->getJson('/api/v1/doctor/dashboard');

    $response->assertOk()
        ->assertJsonStructure(['data' => ['today_appointments', 'total_patients', 'rating']]);
});

test('doctor can start consultation', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['user_id' => $doctorUser->id, 'department_id' => $department->id]);

    $appointment = Appointment::factory()->create([
        'doctor_id' => $doctor->id,
        'status' => 'checked_in',
    ]);

    $token = $doctorUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->putJson("/api/v1/doctor/appointments/{$appointment->id}/start");

    $response->assertOk();
    expect($appointment->fresh()->status)->toBe('in_progress');
});

test('doctor can complete consultation', function () {
    $hospital = Hospital::factory()->create();
    $department = Department::factory()->create(['hospital_id' => $hospital->id]);
    $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $hospital->id]);
    $doctor = Doctor::factory()->create(['user_id' => $doctorUser->id, 'department_id' => $department->id]);

    $appointment = Appointment::factory()->create([
        'doctor_id' => $doctor->id,
        'status' => 'in_progress',
    ]);

    $token = $doctorUser->createToken('auth_token')->plainTextToken;

    $response = $this->withHeader('Authorization', "Bearer {$token}")
        ->putJson("/api/v1/doctor/appointments/{$appointment->id}/complete");

    $response->assertOk();
    expect($appointment->fresh()->status)->toBe('completed');
});
