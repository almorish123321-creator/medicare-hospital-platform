<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\Patient;
use App\Models\User;

beforeEach(function () {
    $this->hospital = Hospital::factory()->create();
    $this->department = Department::factory()->create(['hospital_id' => $this->hospital->id]);
    $this->doctor = Doctor::factory()->create(['department_id' => $this->department->id]);
});

describe('Appointment Management', function () {

    describe('Patient appointment operations', function () {

        test('patient can list their appointments with pagination', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            $patient = Patient::factory()->create(['user_id' => $patientUser->id]);
            Appointment::factory()->count(3)->create(['patient_id' => $patient->id, 'hospital_id' => $this->hospital->id, 'department_id' => $this->department->id]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson('/api/v1/patient/appointments');

            $response->assertOk()
                ->assertJsonStructure([
                    'data',
                    'meta' => ['current_page', 'last_page', 'per_page', 'total'],
                ]);

            expect($response->json('meta.total'))->toBe(3);
        });

        test('patient can view a single appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            $patient = Patient::factory()->create(['user_id' => $patientUser->id]);
            $appointment = Appointment::factory()->create([
                'patient_id' => $patient->id,
                'doctor_id' => $this->doctor->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
            ]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson("/api/v1/patient/appointments/{$appointment->id}");

            $response->assertOk()
                ->assertJsonStructure([
                    'data' => ['id', 'patient_id', 'doctor_id', 'status', 'appointment_date'],
                ]);
        });

        test('patient cannot view another patient appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            Patient::factory()->create(['user_id' => $patientUser->id]);

            $otherPatient = Patient::factory()->create();
            $appointment = Appointment::factory()->create(['patient_id' => $otherPatient->id]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson("/api/v1/patient/appointments/{$appointment->id}");

            $response->assertForbidden();
        });

        test('patient can book a new appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            Patient::factory()->create(['user_id' => $patientUser->id]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->postJson('/api/v1/patient/appointments', [
                    'doctor_id' => $this->doctor->id,
                    'hospital_id' => $this->hospital->id,
                    'department_id' => $this->department->id,
                    'appointment_date' => now()->addDays(5)->toDateString(),
                    'appointment_time' => '14:30',
                    'symptoms' => 'Headache, dizziness',
                    'notes' => 'First visit',
                ]);

            $response->assertCreated()
                ->assertJsonStructure([
                    'message',
                    'data' => ['id', 'patient_id', 'doctor_id', 'status'],
                ]);

            expect($response->json('data.status'))->toBe('pending')
                ->and($response->json('data.type'))->toBe('booked');

            $this->assertDatabaseHas('appointments', [
                'doctor_id' => $this->doctor->id,
                'patient_id' => $patientUser->patient->id,
                'status' => 'pending',
            ]);
        });

        test('patient cannot book appointment in the past', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            Patient::factory()->create(['user_id' => $patientUser->id]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->postJson('/api/v1/patient/appointments', [
                    'doctor_id' => $this->doctor->id,
                    'hospital_id' => $this->hospital->id,
                    'department_id' => $this->department->id,
                    'appointment_date' => now()->subDays(1)->toDateString(),
                    'appointment_time' => '10:00',
                ]);

            $response->assertUnprocessable();
        });

        test('patient can cancel a pending appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            $patient = Patient::factory()->create(['user_id' => $patientUser->id]);
            $appointment = Appointment::factory()->create([
                'patient_id' => $patient->id,
                'doctor_id' => $this->doctor->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
                'status' => 'pending',
            ]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->deleteJson("/api/v1/patient/appointments/{$appointment->id}");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('cancelled');
        });

        test('patient can cancel a confirmed appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            $patient = Patient::factory()->create(['user_id' => $patientUser->id]);
            $appointment = Appointment::factory()->create([
                'patient_id' => $patient->id,
                'status' => 'confirmed',
            ]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->deleteJson("/api/v1/patient/appointments/{$appointment->id}");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('cancelled');
        });

        test('patient cannot cancel a completed appointment', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            $patient = Patient::factory()->create(['user_id' => $patientUser->id]);
            $appointment = Appointment::factory()->create([
                'patient_id' => $patient->id,
                'status' => 'completed',
            ]);

            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->deleteJson("/api/v1/patient/appointments/{$appointment->id}");

            $response->assertUnprocessable();
        });
    });

    describe('Receptionist appointment operations', function () {

        test('receptionist can list today appointments', function () {
            $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $this->hospital->id]);
            $token = $receptionistUser->createToken('auth_token')->plainTextToken;

            Appointment::factory()->count(2)->create([
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
                'appointment_date' => today(),
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson('/api/v1/receptionist/appointments');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);
        });

        test('receptionist can check in a confirmed appointment', function () {
            $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $this->hospital->id]);
            $token = $receptionistUser->createToken('auth_token')->plainTextToken;

            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
                'doctor_id' => $this->doctor->id,
                'status' => 'confirmed',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->putJson("/api/v1/receptionist/appointments/{$appointment->id}/check-in");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('checked_in')
                ->and($appointment->fresh()->queue_number)->not->toBeNull();
        });

        test('receptionist can mark appointment as no-show', function () {
            $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $this->hospital->id]);
            $token = $receptionistUser->createToken('auth_token')->plainTextToken;

            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'status' => 'confirmed',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->putJson("/api/v1/receptionist/appointments/{$appointment->id}/no-show");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('no_show');
        });

        test('receptionist cannot check in appointment from another hospital', function () {
            $otherHospital = Hospital::factory()->create();
            $receptionistUser = User::factory()->create(['role' => 'receptionist', 'hospital_id' => $otherHospital->id]);
            $token = $receptionistUser->createToken('auth_token')->plainTextToken;

            $appointment = Appointment::factory()->create([
                'hospital_id' => $this->hospital->id,
                'status' => 'confirmed',
            ]);

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->putJson("/api/v1/receptionist/appointments/{$appointment->id}/check-in");

            $response->assertForbidden();
        });
    });

    describe('Doctor appointment operations', function () {

        test('doctor can list their appointments', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            $this->doctor->update(['user_id' => $doctorUser->id]);

            Appointment::factory()->count(2)->create([
                'doctor_id' => $this->doctor->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
                'appointment_date' => today(),
            ]);

            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson('/api/v1/doctor/appointments');

            $response->assertOk()
                ->assertJsonStructure(['data', 'meta']);
        });

        test('doctor can view single appointment', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            $this->doctor->update(['user_id' => $doctorUser->id]);

            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $this->department->id,
            ]);

            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson("/api/v1/doctor/appointments/{$appointment->id}");

            $response->assertOk()
                ->assertJsonStructure(['data' => ['id', 'patient_id', 'doctor_id', 'status']]);
        });

        test('doctor cannot view appointment belonging to another doctor', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            $this->doctor->update(['user_id' => $doctorUser->id]);

            $otherDept = Department::factory()->create(['hospital_id' => $this->hospital->id]);
            $otherDoctor = Doctor::factory()->create(['department_id' => $otherDept->id]);

            $appointment = Appointment::factory()->create([
                'doctor_id' => $otherDoctor->id,
                'hospital_id' => $this->hospital->id,
                'department_id' => $otherDept->id,
            ]);

            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson("/api/v1/doctor/appointments/{$appointment->id}");

            $response->assertForbidden();
        });

        test('doctor can start consultation', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            $this->doctor->update(['user_id' => $doctorUser->id]);

            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
            ]);

            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->putJson("/api/v1/doctor/appointments/{$appointment->id}/start");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('in_progress');
        });

        test('doctor can complete consultation', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            $this->doctor->update(['user_id' => $doctorUser->id]);

            $appointment = Appointment::factory()->create([
                'doctor_id' => $this->doctor->id,
                'status' => 'in_progress',
                'appointment_date' => today(),
            ]);

            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->putJson("/api/v1/doctor/appointments/{$appointment->id}/complete");

            $response->assertOk();
            expect($appointment->fresh()->status)->toBe('completed')
                ->and($appointment->fresh()->completed_at)->not->toBeNull();
        });
    });

    describe('Cross-role access control', function () {

        test('patient cannot access doctor appointment endpoints', function () {
            $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
            Patient::factory()->create(['user_id' => $patientUser->id]);
            $token = $patientUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson('/api/v1/doctor/appointments');

            $response->assertForbidden();
        });

        test('doctor cannot access receptionist appointment endpoints', function () {
            $doctorUser = User::factory()->create(['role' => 'doctor', 'hospital_id' => $this->hospital->id]);
            Doctor::factory()->create(['user_id' => $doctorUser->id, 'department_id' => $this->department->id]);
            $token = $doctorUser->createToken('auth_token')->plainTextToken;

            $response = $this->withHeader('Authorization', "Bearer {$token}")
                ->getJson('/api/v1/receptionist/appointments');

            $response->assertForbidden();
        });
    });
});
