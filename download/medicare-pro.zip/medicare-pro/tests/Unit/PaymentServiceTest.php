<?php

use App\Models\Hospital;
use App\Models\Invoice;
use App\Models\Patient;
use App\Models\Payment;
use App\Models\User;
use App\Services\PaymentService;

beforeEach(function () {
    $this->service = new PaymentService();
    $this->hospital = Hospital::factory()->create();
    $patientUser = User::factory()->create(['role' => 'patient', 'hospital_id' => $this->hospital->id]);
    $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);
});

describe('PaymentService', function () {

    describe('generateInvoice', function () {

        test('creates an invoice with correct calculation', function () {
            $invoice = $this->service->generateInvoice([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 100.00,
            ]);

            expect($invoice)->toBeInstanceOf(Invoice::class)
                ->and($invoice->amount)->toBe('100.00')
                ->and($invoice->discount)->toBe('0.00')
                ->and($invoice->tax)->toBe('15.00')
                ->and($invoice->total_amount)->toBe('115.00')
                ->and($invoice->status)->toBe('pending');
        });

        test('applies discount before tax calculation', function () {
            $invoice = $this->service->generateInvoice([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 200.00,
                'discount' => 50.00,
            ]);

            // (200 - 50) * 0.15 = 22.5 tax, total = 150 + 22.5 = 172.5
            expect($invoice->discount)->toBe('50.00')
                ->and($invoice->tax)->toBe('22.50')
                ->and($invoice->total_amount)->toBe('172.50');
        });

        test('links invoice to appointment when provided', function () {
            $appointment = \App\Models\Appointment::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
            ]);

            $invoice = $this->service->generateInvoice([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'appointment_id' => $appointment->id,
                'amount' => 100.00,
            ]);

            expect($invoice->appointment_id)->toBe($appointment->id);
        });

        test('sets status to pending on creation', function () {
            $invoice = $this->service->generateInvoice([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 100.00,
            ]);

            expect($invoice->status)->toBe('pending');
        });

        test('handles zero amount', function () {
            $invoice = $this->service->generateInvoice([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 0,
            ]);

            expect($invoice->total_amount)->toBe('0.00');
        });
    });

    describe('processPayment', function () {

        test('processes cash payment successfully', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'amount' => 100.00,
                'tax' => 15.00,
                'total_amount' => 115.00,
                'status' => 'pending',
            ]);

            $payment = $this->service->processPayment(
                $invoice,
                115.00,
                'cash'
            );

            expect($payment)->toBeInstanceOf(Payment::class)
                ->and($payment->amount)->toBe('115.00')
                ->and($payment->payment_method)->toBe('cash')
                ->and($payment->status)->toBe('success')
                ->and($payment->paid_at)->not->toBeNull();

            expect($invoice->fresh()->status)->toBe('paid');
        });

        test('processes card payment with transaction id', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 115.00,
                'status' => 'pending',
            ]);

            $payment = $this->service->processPayment(
                $invoice,
                115.00,
                'card',
                'txn_1234567890'
            );

            expect($payment->payment_method)->toBe('card')
                ->and($payment->transaction_id)->toBe('txn_1234567890');
        });

        test('processes wallet payment', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 50.00,
                'status' => 'pending',
            ]);

            $payment = $this->service->processPayment(
                $invoice,
                50.00,
                'wallet'
            );

            expect($payment->payment_method)->toBe('wallet')
                ->and($invoice->fresh()->status)->toBe('paid');
        });

        test('processes insurance payment', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 200.00,
                'payment_method' => 'insurance',
                'status' => 'pending',
            ]);

            $payment = $this->service->processPayment(
                $invoice,
                200.00,
                'insurance'
            );

            expect($payment->payment_method)->toBe('insurance')
                ->and($invoice->fresh()->status)->toBe('paid');
        });

        test('creates partial payment when amount is less than total', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 115.00,
                'status' => 'pending',
            ]);

            $this->service->processPayment($invoice, 50.00, 'cash');

            expect($invoice->fresh()->status)->toBe('partially_paid');
        });

        test('marks invoice as paid when cumulative payments cover total', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 115.00,
                'status' => 'pending',
            ]);

            $this->service->processPayment($invoice, 50.00, 'cash');
            expect($invoice->fresh()->status)->toBe('partially_paid');

            $this->service->processPayment($invoice, 65.00, 'card', 'txn_card_001');
            expect($invoice->fresh()->status)->toBe('paid')
                ->and($invoice->fresh()->paid_at)->not->toBeNull();
        });

        test('persists payment record to database', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'pending',
            ]);

            $this->service->processPayment($invoice, 100.00, 'cash');

            $this->assertDatabaseHas('payments', [
                'invoice_id' => $invoice->id,
                'amount' => '100.00',
                'payment_method' => 'cash',
                'status' => 'success',
            ]);
        });
    });

    describe('processRefund', function () {

        test('updates invoice status to refunded', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'paid',
            ]);

            $result = $this->service->processRefund($invoice);

            expect($result->status)->toBe('refunded');
        });

        test('persists refund to database', function () {
            $invoice = Invoice::factory()->create([
                'patient_id' => $this->patient->id,
                'hospital_id' => $this->hospital->id,
                'total_amount' => 100.00,
                'status' => 'paid',
            ]);

            $this->service->processRefund($invoice);

            $this->assertDatabaseHas('invoices', [
                'id' => $invoice->id,
                'status' => 'refunded',
            ]);
        });
    });
});
