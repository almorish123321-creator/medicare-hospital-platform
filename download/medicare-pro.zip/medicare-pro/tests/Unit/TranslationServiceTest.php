<?php

use App\Models\Translation;
use App\Services\TranslationService;
use Illuminate\Support\Facades\Cache;

beforeEach(function () {
    $this->service = new TranslationService();
    Cache::flush();
});

describe('TranslationService', function () {

    describe('get', function () {

        test('returns arabic translation by default', function () {
            Translation::create([
                'key' => 'welcome',
                'group' => 'common',
                'ar' => 'مرحباً',
                'en' => 'Welcome',
            ]);

            $result = $this->service->get('welcome', 'common', 'ar');

            expect($result)->toBe('مرحباً');
        });

        test('returns english translation when requested', function () {
            Translation::create([
                'key' => 'welcome',
                'group' => 'common',
                'ar' => 'مرحباً',
                'en' => 'Welcome',
            ]);

            $result = $this->service->get('welcome', 'common', 'en');

            expect($result)->toBe('Welcome');
        });

        test('returns null when translation key does not exist', function () {
            $result = $this->service->get('nonexistent_key', 'common', 'ar');

            expect($result)->toBeNull();
        });

        test('returns null when translation exists but locale value is empty', function () {
            Translation::create([
                'key' => 'empty_en',
                'group' => 'common',
                'ar' => 'قيمة',
                'en' => null,
            ]);

            $result = $this->service->get('empty_en', 'common', 'en');

            expect($result)->toBeNull();
        });

        test('falls back to application locale when none specified', function () {
            app()->setLocale('ar');

            Translation::create([
                'key' => 'fallback_test',
                'group' => 'messages',
                'ar' => 'اختبار',
                'en' => 'Test',
            ]);

            $result = $this->service->get('fallback_test', 'messages');

            expect($result)->toBe('اختبار');
        });

        test('caches translation result', function () {
            Translation::create([
                'key' => 'cached',
                'group' => 'common',
                'ar' => 'مخزن',
                'en' => 'Cached',
            ]);

            // First call populates cache
            $this->service->get('cached', 'common', 'ar');

            // Verify cache key exists
            expect(Cache::has('trans_common_cached_ar'))->toBeTrue();
        });

        test('returns translations from different groups independently', function () {
            Translation::create([
                'key' => 'submit',
                'group' => 'common',
                'ar' => 'إرسال',
                'en' => 'Submit',
            ]);

            Translation::create([
                'key' => 'submit',
                'group' => 'medical',
                'ar' => 'تقديم',
                'en' => 'Submit Medical',
            ]);

            $commonResult = $this->service->get('submit', 'common', 'ar');
            $medicalResult = $this->service->get('submit', 'medical', 'ar');

            expect($commonResult)->toBe('إرسال')
                ->and($medicalResult)->toBe('تقديم');
        });
    });

    describe('set', function () {

        test('creates a new translation', function () {
            $translation = $this->service->set('new_key', 'common', 'جديد', 'New');

            expect($translation)->toBeInstanceOf(Translation::class)
                ->and($translation->key)->toBe('new_key')
                ->and($translation->group)->toBe('common')
                ->and($translation->ar)->toBe('جديد')
                ->and($translation->en)->toBe('New');

            $this->assertDatabaseHas('translations', [
                'key' => 'new_key',
                'group' => 'common',
                'ar' => 'جديد',
                'en' => 'New',
            ]);
        });

        test('updates existing translation with same key and group', function () {
            Translation::create([
                'key' => 'updatable',
                'group' => 'common',
                'ar' => 'قديم',
                'en' => 'Old',
            ]);

            $translation = $this->service->set('updatable', 'common', 'محدث', 'Updated');

            expect($translation->ar)->toBe('محدث')
                ->and($translation->en)->toBe('Updated');

            $this->assertDatabaseHas('translations', [
                'key' => 'updatable',
                'group' => 'common',
                'ar' => 'محدث',
                'en' => 'Updated',
            ]);

            // Only one record should exist
            expect(Translation::where('key', 'updatable')->where('group', 'common')->count())->toBe(1);
        });

        test('clears cache for both locales when setting a translation', function () {
            // Pre-populate cache
            Cache::put('trans_test_cache_key_ar', 'old_ar_value');
            Cache::put('trans_test_cache_key_en', 'old_en_value');

            $this->service->set('cache_key', 'test', 'جديد', 'New');

            expect(Cache::has('trans_test_cache_key_ar'))->toBeFalse()
                ->and(Cache::has('trans_test_cache_key_en'))->toBeFalse();
        });
    });

    describe('getGroup', function () {

        test('returns all translations in a group as key-value array', function () {
            Translation::create([
                'key' => 'hello',
                'group' => 'greetings',
                'ar' => 'مرحبا',
                'en' => 'Hello',
            ]);

            Translation::create([
                'key' => 'goodbye',
                'group' => 'greetings',
                'ar' => 'مع السلامة',
                'en' => 'Goodbye',
            ]);

            $result = $this->service->getGroup('greetings', 'ar');

            expect($result)->toBeArray()
                ->toHaveKey('hello')
                ->toHaveKey('goodbye')
                ->and($result['hello'])->toBe('مرحبا')
                ->and($result['goodbye'])->toBe('مع السلامة');
        });

        test('returns empty array for group with no translations', function () {
            $result = $this->service->getGroup('nonexistent_group', 'ar');

            expect($result)->toBeArray()
                ->toBeEmpty();
        });

        test('returns only translations from specified group', function () {
            Translation::create([
                'key' => 'name',
                'group' => 'profile',
                'ar' => 'الاسم',
                'en' => 'Name',
            ]);

            Translation::create([
                'key' => 'name',
                'group' => 'common',
                'ar' => 'الاسم العام',
                'en' => 'Common Name',
            ]);

            $result = $this->service->getGroup('profile', 'ar');

            expect($result)->toHaveCount(1)
                ->and($result['name'])->toBe('الاسم');
        });
    });

    describe('clearCache', function () {

        test('clear cache method exists and is callable', function () {
            expect(method_exists($this->service, 'clearCache'))->toBeTrue();

            // Should not throw an exception
            $this->service->clearCache();
            expect(true)->toBeTrue();
        });
    });
});
