<?php

use App\Models\Appointment;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\Patient;
use App\Models\QueueLog;
use App\Models\User;
use App\Services\QueueService;
use Illuminate\Support\Facades\Cache;

beforeEach(function () {
    $this->service = new QueueService();
    $this->hospital = Hospital::factory()->create();
    $this->department = Department::factory()->create([
        'hospital_id' => $this->hospital->id,
    ]);
});

describe('QueueService', function () {

    describe('generateQueueNumber', function () {

        test('generates sequential queue numbers starting from 1', function () {
            Cache::flush();
            $number = $this->service->generateQueueNumber($this->department);

            expect($number)->toBeInt()
                ->toBe(1);
        });

        test('increments queue number on each call', function () {
            Cache::flush();
            $first = $this->service->generateQueueNumber($this->department);
            $second = $this->service->generateQueueNumber($this->department);
            $third = $this->service->generateQueueNumber($this->department);

            expect($first)->toBe(1)
                ->and($second)->toBe(2)
                ->and($third)->toBe(3);
        });

        test('generates independent counters per department', function () {
            Cache::flush();
            $department2 = Department::factory()->create([
                'hospital_id' => $this->hospital->id,
            ]);

            $dept1Number = $this->service->generateQueueNumber($this->department);
            $dept1Number2 = $this->service->generateQueueNumber($this->department);
            $dept2Number = $this->service->generateQueueNumber($department2);

            expect($dept1Number)->toBe(1)
                ->and($dept1Number2)->toBe(2)
                ->and($dept2Number)->toBe(1);
        });

        test('daily reset produces new counter each day', function () {
            Cache::flush();

            // Simulate today's counter
            $this->service->generateQueueNumber($this->department);
            $this->service->generateQueueNumber($this->department);

            // Simulate a new day by clearing cache
            Cache::flush();

            $newDayNumber = $this->service->generateQueueNumber($this->department);

            expect($newDayNumber)->toBe(1);
        });
    });

    describe('queue display number formatting', function () {

        test('queue display number follows D{dept_id}-{seq} format', function () {
            $hospital = Hospital::factory()->create();
            $dept = Department::factory()->create(['hospital_id' => $hospital->id]);
            $appointment = Appointment::factory()->create([
                'department_id' => $dept->id,
                'queue_number' => 5,
            ]);

            $displayNumber = $appointment->getQueueDisplayNumber();

            expect($displayNumber)->toBe("D{$dept->id}-005");
        });

        test('queue display number pads sequence to 3 digits', function () {
            $appointment = Appointment::factory()->make([
                'department_id' => 3,
                'queue_number' => 42,
            ]);

            expect($appointment->getQueueDisplayNumber())->toBe('D3-042');
        });

        test('queue display number handles large sequence numbers', function () {
            $appointment = Appointment::factory()->make([
                'department_id' => 10,
                'queue_number' => 1234,
            ]);

            expect($appointment->getQueueDisplayNumber())->toBe('D10-1234');
        });

        test('queue display number returns null when no queue number assigned', function () {
            $appointment = Appointment::factory()->make([
                'queue_number' => null,
            ]);

            expect($appointment->getQueueDisplayNumber())->toBeNull();
        });
    });

    describe('assignQueueNumber', function () {

        test('assigns a queue number to an appointment', function () {
            Cache::flush();
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);
            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'queue_number' => null,
            ]);

            $this->service->assignQueueNumber($appointment);

            expect($appointment->fresh()->queue_number)->not->toBeNull();
        });

        test('creates a queue log entry when assigning', function () {
            Cache::flush();
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);
            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'queue_number' => null,
            ]);

            $this->service->assignQueueNumber($appointment);

            expect(QueueLog::where('appointment_id', $appointment->id)->exists())->toBeTrue();
        });

        test('queue log has waiting status and estimated wait time', function () {
            Cache::flush();
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);
            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'queue_number' => null,
            ]);

            $this->service->assignQueueNumber($appointment);

            $log = QueueLog::where('appointment_id', $appointment->id)->first();
            expect($log->status)->toBe('waiting')
                ->and($log->estimated_wait_time)->toBeInt();
        });
    });

    describe('callNext', function () {

        test('returns the next checked-in appointment', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $appointment->id,
                'queue_number' => 1,
                'status' => 'waiting',
            ]);

            $next = $this->service->callNext($this->department->id);

            expect($next)->not->toBeNull()
                ->and($next->id)->toBe($appointment->id);
        });

        test('updates appointment status to in_progress', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $appointment->id,
                'queue_number' => 1,
                'status' => 'waiting',
            ]);

            $this->service->callNext($this->department->id);

            expect($appointment->fresh()->status)->toBe('in_progress')
                ->and($appointment->fresh()->started_at)->not->toBeNull();
        });

        test('returns null when no checked-in appointments exist', function () {
            $next = $this->service->callNext($this->department->id);
            expect($next)->toBeNull();
        });

        test('serves appointments in queue number order', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            $appointment2 = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 2,
            ]);

            $appointment1 = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $appointment2->id,
                'queue_number' => 2,
                'status' => 'waiting',
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $appointment1->id,
                'queue_number' => 1,
                'status' => 'waiting',
            ]);

            $next = $this->service->callNext($this->department->id);
            expect($next->id)->toBe($appointment1->id);
        });
    });

    describe('skipCurrent', function () {

        test('skips the current in-progress appointment', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'in_progress',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $appointment->id,
                'queue_number' => 1,
                'status' => 'in_progress',
            ]);

            $skipped = $this->service->skipCurrent($this->department->id);

            expect($skipped)->not->toBeNull()
                ->and($appointment->fresh()->status)->toBe('checked_in');
        });

        test('returns null when no in-progress appointment', function () {
            $skipped = $this->service->skipCurrent($this->department->id);
            expect($skipped)->toBeNull();
        });
    });

    describe('estimateWaitTime', function () {

        test('returns default wait time when no queue data exists', function () {
            $waitTime = $this->service->estimateWaitTime($this->department, 1);

            // With 0 waiting patients, 0 * avg = 0
            expect($waitTime)->toBeInt();
        });

        test('calculates wait time based on waiting count and avg consultation', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            // Create 3 waiting appointments for today
            foreach (range(1, 3) as $i) {
                $appointment = Appointment::factory()->create([
                    'department_id' => $this->department->id,
                    'doctor_id' => $doctor->id,
                    'status' => 'checked_in',
                    'appointment_date' => today(),
                    'queue_number' => $i,
                ]);

                QueueLog::factory()->create([
                    'appointment_id' => $appointment->id,
                    'queue_number' => $i,
                    'status' => 'waiting',
                ]);
            }

            $waitTime = $this->service->estimateWaitTime($this->department, 1);

            // 3 waiting * 15 min default avg = 45
            expect($waitTime)->toBe(45);
        });
    });

    describe('getQueueStatus', function () {

        test('returns queue status structure with all keys', function () {
            $status = $this->service->getQueueStatus($this->department->id);

            expect($status)->toHaveKeys([
                'current_serving',
                'next_patients',
                'completed_today',
                'average_wait_time',
                'waiting_count',
            ]);
        });

        test('current_serving is null when no appointment is in progress', function () {
            $status = $this->service->getQueueStatus($this->department->id);

            expect($status['current_serving'])->toBeNull();
        });

        test('returns current serving when an appointment is in progress', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            $appointment = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'in_progress',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            $status = $this->service->getQueueStatus($this->department->id);

            expect($status['current_serving'])->not->toBeNull();
        });
    });

    describe('priority handling', function () {

        test('queue respects insertion order via queue_number', function () {
            $doctor = Doctor::factory()->create(['department_id' => $this->department->id]);

            // Create appointments with different queue numbers
            $high = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 1,
            ]);

            $low = Appointment::factory()->create([
                'department_id' => $this->department->id,
                'doctor_id' => $doctor->id,
                'status' => 'checked_in',
                'appointment_date' => today(),
                'queue_number' => 5,
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $high->id,
                'queue_number' => 1,
                'status' => 'waiting',
            ]);

            QueueLog::factory()->create([
                'appointment_id' => $low->id,
                'queue_number' => 5,
                'status' => 'waiting',
            ]);

            $next = $this->service->callNext($this->department->id);
            expect($next->id)->toBe($high->id);
        });
    });
});
